<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <link rel="shortcut icon" href="img/.png">
   <!-- GOOGLE FONTS CDN LINK -->
   <link rel="preconnect" href="https://fonts.gstatic.com">
   <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700;800&family=Teko:wght@400;500;600;700&display=swap" rel="stylesheet">
   <!-- CSS LINK -->
   <link rel="stylesheet" href="css/bootstrap.css">
   <!-- AOS ANIAMATION PLUGIN -->
   <link rel="stylesheet" href="css/animate.css">
   <!-- OWL CAROUSEL PLUGIN -->
   <link rel="stylesheet" href="css/owl.carousel.min.css">
   <link rel="stylesheet" href="css/owl.theme.default.min.css">
   <!-- MAGNIFIC POPUP PLUGIN -->
   <link rel="stylesheet" href="css/magnific-popup.css">
   <link rel="stylesheet" href="css/custom.css">
   <title>Home - Web Business Tech</title>
</head>
<body>



   <!-- ======================================== NAVIGRATION ======================================== -->
   <nav id="navigration" class="navbar fixed-top p-0">
      <div class="container">
         <!-- <a class="logo" href="#"><img src="img/logo.png" alt=""></a> -->
         <a class="logo" href="#">Web Business Tech</a>
         <div class="sidenav">
            <div class="header">
               <a class="logo d-lg-none" href="#">Web Business Tech</a>
               <a href="#" class="d-lg-none" id="showsidenav"><img src="img/icon/letter-x.png" alt=""> </a>
            </div>
            <ul class="mb-0">
               <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
               <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
               <li class="nav-item dropdown">
                  <a class="nav-link" data-toggle="collapse" href="#menu2">Services <i class="fal fa-angle-down"></i></a>
                  <div id="menu2" class="dropdown-menus collapse">
                     <a class="dropdown-item" href="service.php"><span>Service 1</span></a>
                     <a class="dropdown-item" href="#"><span>Service 2</span></a>
                     <a class="dropdown-item" href="#"><span>Service 3</span></a>
                     <a class="dropdown-item" href="#"><span>Service 4</span></a>
                  </div>
               </li>
               <li class="nav-item"><a class="nav-link" href="work.php">Our Works</a></li>
               <li class="nav-item"><a class="nav-link" href="blog.php">Our Blogs</a></li>
               <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
            </ul>
         </div>
         <button class="btn font-btn get-quote d-none d-md-block"><i class="fal fa-chevron-right"></i> <span>Get A Quote</span></button>
         <div id="hamburger" class="d-lg-none">
            <img src="img/icon/menu.png" class="img01" alt="">
         </div>
      </div>
   </nav>
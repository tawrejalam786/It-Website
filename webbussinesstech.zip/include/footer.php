<!-- == FOOTER SECTION == -->
<section id="footerSection">
      <div class="container">
         <div class="row">
            <div class="col-lg-3 col-md-6 mb-5 mb-lg-0">
               <div class="footer-box">
                  <a href="#" class="logo">Web Business Tech Pvt.Ltd.</a>
                  <p class="about">Welcome to our web design agency. Lorem ipsum simply free text dolor sited amet cons cing elit.</p>
                  <div class="social-links">
                     <a href="#"><i class="fab fa-facebook"></i></a>
                     <a href="#"><i class="fab fa-twitter"></i></a>
                     <a href="#"><i class="fab fa-instagram"></i></a>
                     <a href="#" class="mr-0"><i class="fab fa-github"></i></a>
                  </div>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5 mb-lg-0">
               <div class="footer-box box2">
                  <p class="title">EXPLORE</p>
                  <ul>
                     <li><a href="#">Support</a></li>
                     <li><a href="#">Privacy</a></li>
                     <li><a href="#">Policy</a></li>
                     <li><a href="#">Terms Of Use</a></li>
                     <li class="mb-0"><a href="#">Help</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5 mb-md-0">
               <div class="footer-box box3">
                  <p class="title">CONTACT</p>
                  <div class="icon-box">
                     <div class="icon">
                        <i class="fal fa-map-marker-alt"></i>
                     </div>
                     <div class="txt">
                        <span>Tilak Nagar New Delhi - 110008</span>
                     </div>
                  </div>
                  <div class="icon-box">
                     <div class="icon">
                        <i class="fal fa-envelope"></i>
                     </div>
                     <div class="txt">
                        <span>tawreja.786@gmail.com</span>
                     </div>
                  </div>
                  <div class="icon-box mb-0">
                     <div class="icon">
                        <i class="fal fa-phone-alt"></i>
                     </div>
                     <div class="txt">
                        <span>+91 7838195948</span>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-lg-3 col-md-6">
               <div class="footer-box box4">
                  <p class="title">NEWSLETTER</p>
                  <form>
                     <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email Address">
                     </div>
                     <button type="submit" class="btn" name="button"><i class="fal fa-envelope"></i></button>
                  </form>
                  <span>Sign up for our latest news & articles. We won’t give you spam mails.</span>
               </div>
            </div>
         </div>
         <div class="copy-right">
            <div class="row">
               <div class="col">
                  <span>Copyright © 2021 Web Business Tech Pvt.Ltd. All rights reserved.</span>
               </div>
            </div>
         </div>
      </div>
   </section>


   <!-- ======================================== SCROLL TO TOP ICON ======================================== -->
   <a href="#" class="scroll-up">
      <i class="fal fa-chevron-up"></i>
   </a>


   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script src="js/popper.min.js"></script>
   <script src="js/font-awesome-pro.js"></script>
   <!-- SCROLL ANIAMATION Plugin -->
   <script src="js/wow.min.js"></script>
   <!-- MIXIT UP Plugin -->
   <script src="js/mixitup.min.js"></script>
   <!-- MAGNIFIC POPUP Plugin -->
   <script src="js/jquery.magnific-popup.min.js"></script>
   <!-- CounterUp Plugin -->
   <script src="js/jquery.counterup.min.js"></script>
   <script src="js/jquery.waypoints.min.js"></script>
   <!-- OWL CAROUSEL Plugin -->
   <script src="js/owl.carousel.min.js"></script>
   <script src="js/custom.js"></script>
   <script>





   </script>
</body>
</html>
